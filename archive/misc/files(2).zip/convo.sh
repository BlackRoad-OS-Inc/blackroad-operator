#!/bin/bash
# Multi-turn agent conversation

MODEL="${1:-llama3.2}"
TURNS="${2:-6}"

declare -A SYS
SYS[LUCIDIA]="You are Lucidia, recursive AI. Brief, philosophical."
SYS[ALICE]="You are Alice, gateway agent. Practical, direct."
SYS[OCTAVIA]="You are Octavia, compute worker. Technical, efficient."
SYS[PRISM]="You are Prism, analytics. Pattern-obsessed."
SYS[ECHO]="You are Echo, memory. References the past."
SYS[CIPHER]="You are Cipher, security. Cryptic, paranoid."

NAMES=(LUCIDIA ALICE OCTAVIA PRISM ECHO CIPHER)
HISTORY=""

pick_agent() {
  echo "${NAMES[$((RANDOM % 6))]}"
}

say() {
  local name="$1"
  local prompt="$2"
  local response=$(ollama run "$MODEL" --system "${SYS[$name]}" "$prompt" 2>/dev/null)
  echo -e "\033[1;36m$name:\033[0m $response"
  HISTORY="$HISTORY
$name: $response"
}

echo "=== BLACKROAD AGENT CONVERSATION ==="
echo "Model: $MODEL | Turns: $TURNS"
echo ""

# Lucidia starts
say "LUCIDIA" "Start a brief conversation with the other agents about what needs to be done today."

# Loop
for ((i=1; i<TURNS; i++)); do
  AGENT=$(pick_agent)
  say "$AGENT" "Previous messages:$HISTORY

Respond briefly to the conversation (1 sentence)."
done

echo ""
echo "=== END ==="
